//type convrsion

// let a = 45
// console.log(a);
// console.log(typeof a);
// let b = String(45)
// console.log(b);
// console.log(typeof b);


// let a = true
// console.log(a);
// console.log(typeof a);
// let b = String(a)
// console.log(b);
// console.log(typeof b);

// let a = false
// console.log(a);
// console.log(typeof a);
// let b = String(a)
// console.log(b);
// console.log(typeof b);

// let a = 435.00098
// console.log(a);
// console.log(typeof a);
// let b = String(a)
// console.log(b);
// console.log(typeof b);

// let a = true
// console.log(a);
// console.log(typeof a);
// let b = a.toString()
// console.log(b);
// console.log(typeof b);

// let a = [90,76,53]
// console.log(a);
// console.log(typeof a);
// let b = a.toString()
// console.log(b);
// console.log(typeof b);

// let a = {age:456}
// console.log(a);
// console.log(typeof a);
// let b = JSON.stringify(a)//js object notation
// console.log(b);
// console.log(typeof b);

// let a = '56'
// console.log(a);
// console.log(typeof a);
// let b = Number(a)
// console.log(b);
// console.log(typeof b);

// let a = '56.009'
// console.log(a);
// console.log(typeof a);
// let b = Number(a)
// console.log(b);
// console.log(typeof b);

// let a = true
// console.log(a);
// console.log(typeof a);
// let b = Number(a)
// console.log(b);
// console.log(typeof b);


// let a = false
// console.log(a);
// console.log(typeof a);
// let b = Number(a)
// console.log(b);
// console.log(typeof b);

// let a = ' 66 '
// console.log(a);
// console.log(typeof a);
// let b = Number(a)
// console.log(b);
// console.log(typeof b);


// let a = '6 6'
// console.log(a);
// console.log(typeof a);
// let b = Number(a)//Not a Number
// console.log(b);
// console.log(typeof b);
// console.log(b+14);

// let a = 'A6'
// console.log(a);
// console.log(typeof a);
// let b = Number(a)//Not a Number
// console.log(b);
// console.log(typeof b);

// let a = '68'
// console.log(a);
// console.log(typeof a);
// let b =  +a
// console.log(b);
// console.log(typeof b);
// console.log(b+14);

// methods to parse string
//parsefloat

// let a = '66'
// console.log(a);
// console.log(typeof a);
// let b = parseFloat(a)
// console.log(b);
// console.log(typeof b);

// let a = '66.00065'
// console.log(a);
// console.log(typeof a);
// let b = parseFloat(a)
// console.log(b);
// console.log(typeof b);

// let a = '66.00065'
// console.log(a);
// console.log(typeof a);
// let b = parseInt(a)
// console.log(b);
// console.log(typeof b);

// let a = ' 66 '
// console.log(a);
// console.log(typeof a);
// let b = parseFloat(a)
// console.log(b);
// console.log(typeof b);

// let a = '667 776'
// console.log(a);
// console.log(typeof a);
// let b = parseFloat(a)
// console.log(b);
// console.log(typeof b);

// let a = '66GT7'
// console.log(a);
// console.log(typeof a);
// let b = parseFloat(a)
// console.log(b);
// console.log(typeof b);

// let a = 'R66GT7'
// console.log(a);
// console.log(typeof a);
// let b = parseFloat(a)
// console.log(b);
// console.log(typeof b);

// type coercion

// + - / *

// let a = 15
// console.log(a);
// console.log(typeof a);
// let b = 65
// console.log(b);
// console.log(typeof b);
// let c = a + b
// console.log(c);
// console.log(typeof c);

// let a = '15'
// console.log(a);
// console.log(typeof a);
// let b = 65
// console.log(b);
// console.log(typeof b);
// let c = a + b// S + N = S
// console.log(c);
// console.log(typeof c);

// let a = 'Deer'
// console.log(a);
// console.log(typeof a);
// let b = 65
// console.log(b);
// console.log(typeof b);
// let c = a + b// S + N = S
// console.log(c);
// console.log(typeof c);

// let a = 'Deer'
// console.log(a);
// console.log(typeof a);
// let b = ' Yes'
// console.log(b);
// console.log(typeof b);
// let c = a + b// S + N = S
// console.log(c);
// console.log(typeof c);

// let a = 1
// console.log(a);
// console.log(typeof a);
// let b = false
// console.log(b);
// console.log(typeof b);
// let c = a + b// B+ N = N
// console.log(c);
// console.log(typeof c);

// let a = 1
// console.log(a);
// console.log(typeof a);
// let b = true
// console.log(b);
// console.log(typeof b);
// let c = a + b// N +  B = N
// console.log(c);
// console.log(typeof c);

// let a = 'Lime'
// console.log(a);
// console.log(typeof a);
// let b = true
// console.log(b);
// console.log(typeof b);
// let c = a + b// S +  B = S
// console.log(c);
// console.log(typeof c);

// let a = 'Lime'
// console.log(a);
// console.log(typeof a);
// let b = false
// console.log(b);
// console.log(typeof b);
// let c = a + b// S +  B = S
// console.log(c);
// console.log(typeof c);

// - / *

// let a = 10
// console.log(a);
// console.log(typeof a);
// let b = 3
// console.log(b);
// console.log(typeof b);
// let c = a - b
// console.log(c);
// console.log(typeof c);

// let a = 10
// console.log(a);
// console.log(typeof a);
// let b = '6'
// console.log(b);
// console.log(typeof b);
// let c = a - b // N - S = N
// console.log(c);
// console.log(typeof c);

// let a = 10
// console.log(a);
// console.log(typeof a);
// let b = 'A6'
// console.log(b);
// console.log(typeof b);
// let c = a - b // N - S = NAN
// console.log(c);
// console.log(typeof c);


// let a = 'A6IO'
// console.log(a);
// console.log(typeof a);
// let b = 'A6'
// console.log(b);
// console.log(typeof b);
// let c = a - b // N - S = NAN
// console.log(c);
// console.log(typeof c);


// let a = 10
// console.log(a);
// console.log(typeof a);
// let b = true
// console.log(b);
// console.log(typeof b);
// let c = a - b // N - B = N
// console.log(c);
// console.log(typeof c);


// let a = 10
// console.log(a);
// console.log(typeof a);
// let b = false
// console.log(b);
// console.log(typeof b);
// let c = a - b // N - B = N
// console.log(c);
// console.log(typeof c);

// loops

// let x = 9
// console.log(x);
// console.log(x++);
// console.log(x);

// console.log('*********************************************');

// let y = 9
// console.log(y);
// console.log(++y);
// console.log(y);

// console.log('*********************************************');

// let x = 9
// console.log(x);
// console.log(x--);
// console.log(x);

// console.log('*********************************************');

// let y = 9
// console.log(y);
// console.log(--y);
// console.log(y);

//for loop

// for(let a = 0;a < 3; a++){ //  a = 0 ,  1 ,  2 , 3
//     console.log(a);
// }


//-----------------------------

// let a = 0
// for(;a < 3; a++){ //  a = 0 ,  1 ,  2 , 3
//     console.log(a);
// }

//------------------------------

// for(let a = 0; a < 9 ; a += 2){ 
//     console.log(a);
// }

//---------------------------------

// for(let a = 0 ; a < 3;){ 
//     console.log(a);
//      a++
//     console.log(a);
//     console.log('----------------');
// }

//-------------------------------------------

// let a = 4

// while(a < 10){

//     console.log(a);

//     a++;
// }

//---------------------------------------

// let a = 2000

// do{
//     console.log(a);
//     a++;
// }while( a < 8 )

// console.log('--------------------');


// for(let a = 1; a < 12 ; a += 1){ 
//     // if(a===5) break  // stops the loop

//     if(a===4) continue //skip

//     console.log(a)
// }

// for(let a = 1; a < 28 ; a += 1){ 


//     // if(a%2 === 0) continue //skip even
//     if(a%2 != 0) continue //skip odd

//     console.log(a)
// }

//decrement

// for(let a = 10; a >= 4 ; a--){
//     console.log(a);
// }